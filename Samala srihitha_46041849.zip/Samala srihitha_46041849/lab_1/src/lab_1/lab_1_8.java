package lab_1;

public class lab_1_8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
