package lab_1;

import java.util.Scanner;

public class lab_1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc=new Scanner(System.in);
		    int n=sc.nextInt();
		    int sum=0;
		    for(int i=0;i<=n;i++)
		    {
		        sum=sum+(i*i*i);
		    }

			System.out.println("sum: "+sum);

	}

}
