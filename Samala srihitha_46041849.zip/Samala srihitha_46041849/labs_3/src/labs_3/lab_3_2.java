package labs_3;

import java.util.Scanner;

public class lab_3_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		String s=new StringBuffer(str).reverse().toString();
		System.out.println(str+"|"+s);

	}

}
