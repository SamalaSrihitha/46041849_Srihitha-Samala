package labs_3;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class lab_3_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
        int year,month,date;
         year=sc.nextInt();
         month=sc.nextInt();
         date=sc.nextInt();
        LocalDate pdate = LocalDate.of(year, month, date);
        LocalDate now = LocalDate.now();
 
        Period diff = Period.between(pdate, now);
 
     System.out.printf("Duration %d years, %d months and %d days old\n\n", 
                    diff.getYears(), diff.getMonths(), diff.getDays());

	}

}
