package labs_3;

import java.util.Scanner;

public class lab_3_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String s=sc.nextLine();
		s=s.replace(" ","");
		String temp="";
		for(int i=0;i<s.length();i++)
		{
			if(temp.toLowerCase().contains(s.charAt(i)+" "))
			{
				temp+=s.charAt(i);
			}
		}
		int count=0;
		for(int i=0;i<temp.length();i++)
		{
			for(int j=0;j<s.length();j++)
			{
				if((temp.charAt(i))==(s.charAt(j)))
				{
					count++;
				}
					
			}
			System.out.println("no of times"+temp.charAt(i)+"is"+count);
			count=0;
		}

	}

}
