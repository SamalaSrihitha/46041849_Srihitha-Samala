
public class JournalPaper {

}
