package lab_5;
class EmployeeException extends Exception
{
    EmployeeException(String sentence)
    {
        super(sentence);
    }
}
public class lab_5_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int salary=2900;
		try
		{
			if(salary<3000)
			{
			throw new EmployeeException("valid");	
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
