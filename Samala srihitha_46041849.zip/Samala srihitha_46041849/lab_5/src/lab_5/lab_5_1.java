package lab_5;

class AgeValidationException extends Exception
{
    AgeValidationException(String sentence)
    {
        super(sentence);
    }
}
public class lab_5_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=12;
		try
		{
			if(age>15)
			{
			throw new AgeValidationException("valid");	
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
