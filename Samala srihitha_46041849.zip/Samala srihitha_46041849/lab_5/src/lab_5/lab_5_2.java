package lab_5;
class NameValidationException extends Exception
{
    NameValidationException(String sentence)
    {
        super(sentence);
    }
}

public class lab_5_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String FirstName="Samala";
		String lastName="Srihitha";
		try
		{
			if(FirstName==" " && lastName==" ")
			{
			throw new NameValidationException("not valid");	
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
