package lab_2;

public class lab_2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
